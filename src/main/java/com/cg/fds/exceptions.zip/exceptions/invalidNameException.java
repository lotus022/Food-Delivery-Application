package com.cg.fds.exceptions;

public class invalidNameException extends Exception {

	public invalidNameException(String msg)
	{
		super(msg);
	}
}
