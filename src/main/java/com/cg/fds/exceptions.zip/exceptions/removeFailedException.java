package com.cg.fds.exceptions;

public class removeFailedException  extends Exception{

	public removeFailedException(String msg)
	{
		super(msg);
	}
}
